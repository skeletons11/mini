    <footer class="footer fixed-bottom py-3 bg-dark">
        <div class="container text-center">
        <span class="text-white">&COPY; Copy right by rapat, 2024.</span><br>
        <span class="text-white">Information Technology Program, NPRU.</span>
        </div>
    </footer>
    <!-- End Footer -->
    </body>
</html>